# Project E.V — Build Log

## What's built so far

**Step 1 — Foundation skeleton**
- Kotlin + Jetpack Compose + MVVM + Hilt (DI)
- Dark futuristic theme: black/purple/blue neon, glassmorphism panels (`ui/theme/`)
- Navigation graph with Home, Conversation, Camera Vision, Settings routes

**Step 2 — Live Voice AI core**
- Real-time streaming voice conversation over Gemini Live API (WebSocket)
- Mic capture at 16kHz PCM16 (`voice/AudioCapture.kt`)
- Speaker playback at 24kHz PCM16 (`voice/AudioPlayback.kt`)
- Bilingual/trilingual system persona (English / Hindi / Gujarati, natural code-switching)
- Live transcript UI with state-driven orb (idle / listening / thinking / speaking)

## How to open

1. Open this folder in **Android Studio (Koala or newer)**.
2. Let Gradle sync — it will pull all dependencies automatically.
3. Create `local.properties` in the project root (same folder as `settings.gradle.kts`) if it doesn't already exist, and add:
   ```
   gemini.api.key=YOUR_GEMINI_API_KEY_HERE
   ```
   Get a key at https://aistudio.google.com/apikey. **Never commit this file** — it's already covered by the default Android `.gitignore`.
4. Run on a device or emulator with a microphone (API 26+).
5. Tap **"Talk to E.V"** on the home screen, grant mic permission, and start talking — try switching between English, Hindi, and Gujarati mid-conversation.

## Known things to double check before shipping

- The Live API endpoint/model name in `LiveVoiceClient.kt` (`gemini-2.0-flash-live-001`) — Google updates Live API model names periodically; verify against https://ai.google.dev/gemini-api/docs/live before release.
- `RECORD_AUDIO` uses `VOICE_COMMUNICATION` source for echo cancellation — test on a couple of real devices, behavior varies by OEM.

**Step 3 — Device control**
- `device/DeviceController.kt`: open/close apps, camera, flashlight, brightness, volume, alarms, timers, music play/pause, calls, WhatsApp (pre-filled chat — see note below), browser, Google search, Settings
- `device/NotificationReaderService.kt`: reads posted notifications (needs a one-time manual grant, see below)
- **Wired into the AI itself**: `LiveVoiceClient` declares every device action as a callable function (Gemini function calling). When you say "turn on the flashlight," the model decides to call `toggle_flashlight`, `CommandDispatcher` executes it for real, and the result goes back to the model so it can confirm out loud.
- WhatsApp note: there is no public API for a third-party app to silently send a WhatsApp message — this opens a pre-filled chat and you tap Send. That's a WhatsApp/Meta platform restriction, not something any app can code around.
- Notification reading requires a manual one-time grant: `NotificationReaderService.notificationAccessSettingsIntent()` sends the user to the right settings screen (Android doesn't allow requesting this via a normal permission dialog).
- Brightness control similarly needs a one-time `WRITE_SETTINGS` grant — `DeviceController.requestWriteSettingsIntent()` handles that.

**Step 4 — Camera vision**
- `vision/VisionAnalyzer.kt`: CameraX `ImageAnalysis` pipeline running ML Kit face detection, object detection, and OCR on-device (no network round trip, works offline)
- `ui/screens/CameraVisionScreen.kt`: live camera preview with bounding-box overlay + a readout panel showing detected faces/objects/text
- Gesture detection and richer "scene understanding" (beyond object labels) aren't in this pass — ML Kit's on-device models cover faces/objects/text well but not general scene description; that would need a cloud vision call, which trades off latency and offline capability.

**Step 5 — Memory + personality**
- `memory/` — Room database storing categorized facts (routine, homework, trading, boxing, football, study, preference)
- The AI can call `remember_fact` / `recall_facts` as tools mid-conversation, same mechanism as device control
- Every new voice session loads a summary of what's already known about the user into the system instruction, so E.V "remembers" across app restarts
- Personality (friendly, funny, motivating, light roasting when the user's avoiding their own stated goals — never mean) is encoded directly in the system instruction in `LiveVoiceClient.kt`

## Architecture notes for future phases (not yet built)

These aren't stubbed out with placeholder code — per the brief, placeholder implementations create more confusion than value. Instead, here's how the existing architecture is meant to extend:

- **Floating avatar**: would be a new `Service` + `WindowManager` overlay view (needs `SYSTEM_ALERT_WINDOW`, already declared in the manifest), subscribing to `VoiceRepository.state` to animate based on listening/speaking/thinking.
- **Offline AI mode**: would require a fully on-device model (e.g. via MediaPipe/Gemini Nano where supported) as an alternate `VoiceRepository` implementation behind the same interface — the Live API path wouldn't change.
- **PC control / smart home**: separate transport layer (local network socket or a cloud relay) with its own `CommandDispatcher`-style action mapping, reusing the same function-calling pattern already proven for Android device control.
- **Trading / football / boxing / study coach modules**: each would be a specialized system-instruction + tool-declaration set loaded per "mode," built on the same memory categories already in `MemoryRepository`.

## Next steps

Every remaining piece above is a substantial build in its own right — happy to build any of them next as real, working code, the same way Steps 1-5 were done.
