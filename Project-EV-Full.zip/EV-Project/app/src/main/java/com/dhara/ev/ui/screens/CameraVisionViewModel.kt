package com.dhara.ev.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dhara.ev.vision.VisionAnalyzer
import com.dhara.ev.vision.VisionFrameResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

@HiltViewModel
class CameraVisionViewModel @Inject constructor() : ViewModel() {

    // Owned here (not injected as a singleton) since it's tied to this
    // screen's camera session lifecycle.
    val analyzer: VisionAnalyzer by lazy { VisionAnalyzer(viewModelScope) }

    val result: StateFlow<VisionFrameResult> get() = analyzer.result
}
