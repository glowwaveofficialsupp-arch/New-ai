package com.dhara.ev.device

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Result of a device-control command, so the voice layer can tell the
 * user what actually happened ("Opened Chrome" vs "Couldn't find that app").
 */
data class CommandResult(val success: Boolean, val message: String)

@Singleton
class DeviceController @Inject constructor(
    private val context: Context,
    private val flashlightController: FlashlightController
) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    // ---------- Apps ----------

    fun openApp(appName: String): CommandResult {
        val pm = context.packageManager
        val packages = pm.getInstalledApplications(0)
        val match = packages.firstOrNull {
            pm.getApplicationLabel(it).toString().contains(appName, ignoreCase = true)
        } ?: return CommandResult(false, "Couldn't find an app called $appName")

        val launchIntent = pm.getLaunchIntentForPackage(match.packageName)
            ?: return CommandResult(false, "$appName can't be launched directly")

        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        return CommandResult(true, "Opened ${pm.getApplicationLabel(match)}")
    }

    /**
     * Android does not allow one app to force-kill another in the
     * foreground (by design, since API 21+). This only clears an app's
     * *background* process, which is the closest permitted equivalent.
     */
    fun closeApp(packageName: String): CommandResult {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return try {
            am.killBackgroundProcesses(packageName)
            CommandResult(true, "Cleared $packageName from background")
        } catch (e: Exception) {
            CommandResult(false, "Couldn't close $packageName: ${e.message}")
        }
    }

    // ---------- Camera / flashlight ----------

    fun openCamera(): CommandResult {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            CommandResult(true, "Camera opened")
        } else CommandResult(false, "No camera app found")
    }

    fun toggleFlashlight(on: Boolean): CommandResult {
        val ok = flashlightController.setTorch(on)
        return CommandResult(ok, if (ok) "Flashlight ${if (on) "on" else "off"}" else "Couldn't access the flashlight")
    }

    // ---------- Brightness / volume ----------

    /** Requires the user to have granted WRITE_SETTINGS (special permission, see [canWriteSettings]). */
    fun setBrightness(percent: Int): CommandResult {
        if (!canWriteSettings()) return CommandResult(false, "Need permission to change system brightness")
        val value = (percent.coerceIn(0, 100) * 255 / 100)
        Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, value)
        return CommandResult(true, "Brightness set to $percent%")
    }

    fun canWriteSettings(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.System.canWrite(context)

    fun requestWriteSettingsIntent(): Intent =
        Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun setVolume(percent: Int, stream: Int = AudioManager.STREAM_MUSIC): CommandResult {
        val max = audioManager.getStreamMaxVolume(stream)
        val target = (percent.coerceIn(0, 100) * max / 100)
        audioManager.setStreamVolume(stream, target, 0)
        return CommandResult(true, "Volume set to $percent%")
    }

    // ---------- Alarms / timers ----------

    fun setAlarm(hour: Int, minute: Int, label: String = "E.V alarm"): CommandResult {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            CommandResult(true, "Alarm set for %02d:%02d".format(hour, minute))
        } else CommandResult(false, "No clock app found")
    }

    fun setTimer(seconds: Int, label: String = "E.V timer"): CommandResult {
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            CommandResult(true, "Timer set for ${seconds}s")
        } else CommandResult(false, "No clock app found")
    }

    // ---------- Music ----------
    // Best-effort: dispatches a media-button event to whichever app currently
    // holds audio focus. Works for most players (Spotify, YT Music, etc.)
    // without needing that app's own API integration.

    fun playPauseMusic(): CommandResult {
        dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        return CommandResult(true, "Toggled playback")
    }

    fun pauseMusic(): CommandResult {
        dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE)
        return CommandResult(true, "Paused")
    }

    private fun dispatchMediaKey(keyCode: Int) {
        val down = KeyEvent(KeyEvent.ACTION_DOWN, keyCode)
        val up = KeyEvent(KeyEvent.ACTION_UP, keyCode)
        audioManager.dispatchMediaKeyEvent(down)
        audioManager.dispatchMediaKeyEvent(up)
    }

    // ---------- Calls ----------

    /** Requires CALL_PHONE permission (already declared in the manifest). */
    fun callNumber(number: String): CommandResult {
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            CommandResult(true, "Calling $number")
        } catch (e: SecurityException) {
            CommandResult(false, "Call permission not granted")
        }
    }

    // ---------- WhatsApp ----------
    // WhatsApp has no public API for silently sending a message from a
    // third-party app. This opens a pre-filled chat; the user still taps
    // Send themselves — that's a WhatsApp/Meta platform restriction, not
    // a limitation we can code around.

    fun openWhatsAppChat(phoneNumberWithCountryCode: String, message: String): CommandResult {
        val uri = Uri.parse("https://wa.me/$phoneNumberWithCountryCode?text=${Uri.encode(message)}")
        val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            CommandResult(true, "Opened WhatsApp chat — tap send to confirm")
        } else CommandResult(false, "WhatsApp isn't installed")
    }

    // ---------- Browser / search ----------

    fun openBrowser(url: String = "https://www.google.com"): CommandResult {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return CommandResult(true, "Opened browser")
    }

    fun searchGoogle(query: String): CommandResult {
        val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra(android.app.SearchManager.QUERY, query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            CommandResult(true, "Searching for $query")
        } else openBrowser("https://www.google.com/search?q=${Uri.encode(query)}")
    }

    // ---------- Settings ----------

    fun openSettings(): CommandResult {
        context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return CommandResult(true, "Opened Settings")
    }
}
