package com.dhara.ev.device

import android.content.Context
import android.hardware.camera2.CameraManager
import javax.inject.Inject

class FlashlightController @Inject constructor(context: Context) {
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val torchCameraId: String? = cameraManager.cameraIdList.firstOrNull { id ->
        cameraManager.getCameraCharacteristics(id)
            .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
    }

    fun setTorch(on: Boolean): Boolean {
        val id = torchCameraId ?: return false
        return try {
            cameraManager.setTorchMode(id, on)
            true
        } catch (e: Exception) {
            false
        }
    }
}
