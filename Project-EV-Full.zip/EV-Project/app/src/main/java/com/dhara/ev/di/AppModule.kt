package com.dhara.ev.di

import android.content.Context
import com.dhara.ev.device.DeviceController
import com.dhara.ev.device.FlashlightController
import com.dhara.ev.memory.EVDatabase
import com.dhara.ev.memory.MemoryRepository
import com.dhara.ev.voice.LiveApiKeyProvider
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideLiveApiKeyProvider(): LiveApiKeyProvider = LiveApiKeyProvider()

    @Provides
    @Singleton
    fun provideFlashlightController(@ApplicationContext context: Context): FlashlightController =
        FlashlightController(context)

    @Provides
    @Singleton
    fun provideDeviceController(
        @ApplicationContext context: Context,
        flashlightController: FlashlightController
    ): DeviceController = DeviceController(context, flashlightController)

    @Provides
    @Singleton
    fun provideEVDatabase(@ApplicationContext context: Context): EVDatabase =
        EVDatabase.getInstance(context)

    @Provides
    @Singleton
    fun provideMemoryRepository(db: EVDatabase): MemoryRepository = MemoryRepository(db)
}
