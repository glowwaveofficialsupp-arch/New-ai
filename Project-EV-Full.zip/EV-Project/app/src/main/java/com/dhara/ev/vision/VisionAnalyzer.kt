package com.dhara.ev.vision

import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * Runs three ML Kit pipelines per camera frame — face detection, object
 * detection, and OCR — and publishes a merged result. All three run
 * on-device, so this works with no network round trip (low latency,
 * works offline for the vision half of the pipeline).
 */
class VisionAnalyzer(private val scope: CoroutineScope) : ImageAnalysis.Analyzer {

    private val faceDetector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL) // enables smilingProbability
            .build()
    )

    private val objectDetector = ObjectDetection.getClient(
        ObjectDetectorOptions.Builder()
            .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
            .enableClassification()
            .build()
    )

    private val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private val _result = MutableStateFlow(VisionFrameResult())
    val result: StateFlow<VisionFrameResult> = _result.asStateFlow()

    private var busy = false

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage == null || busy) {
            imageProxy.close()
            return
        }
        busy = true

        val input = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)

        scope.launch {
            try {
                val faces = faceDetector.process(input).await().map {
                    DetectedFace(
                        boundingBoxLeft = it.boundingBox.left.toFloat(),
                        boundingBoxTop = it.boundingBox.top.toFloat(),
                        boundingBoxRight = it.boundingBox.right.toFloat(),
                        boundingBoxBottom = it.boundingBox.bottom.toFloat(),
                        smilingProbability = it.smilingProbability
                    )
                }

                val objects = objectDetector.process(input).await().map {
                    DetectedObject(
                        label = it.labels.firstOrNull()?.text ?: "object",
                        confidence = it.labels.firstOrNull()?.confidence ?: 0f,
                        boundingBoxLeft = it.boundingBox.left.toFloat(),
                        boundingBoxTop = it.boundingBox.top.toFloat(),
                        boundingBoxRight = it.boundingBox.right.toFloat(),
                        boundingBoxBottom = it.boundingBox.bottom.toFloat()
                    )
                }

                val text = textRecognizer.process(input).await().text
                    .takeIf { it.isNotBlank() }
                    ?.let { DetectedText(it) }

                _result.value = VisionFrameResult(
                    faces = faces,
                    objects = objects,
                    text = text,
                    imageWidth = input.width,
                    imageHeight = input.height
                )
            } catch (e: Exception) {
                // Swallow per-frame failures — next frame will retry.
            } finally {
                busy = false
                imageProxy.close()
            }
        }
    }
}
