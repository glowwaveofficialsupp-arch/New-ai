package com.dhara.ev.memory

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [MemoryEntry::class], version = 1, exportSchema = false)
abstract class EVDatabase : RoomDatabase() {
    abstract fun memoryDao(): MemoryDao

    companion object {
        @Volatile private var instance: EVDatabase? = null

        fun getInstance(context: Context): EVDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(context, EVDatabase::class.java, "ev_memory.db")
                    .build()
                    .also { instance = it }
            }
    }
}
