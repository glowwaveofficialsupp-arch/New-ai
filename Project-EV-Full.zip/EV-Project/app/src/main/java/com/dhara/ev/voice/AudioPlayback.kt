package com.dhara.ev.voice

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack

/**
 * Plays back the raw PCM16 audio chunks streamed from the Live API
 * (E.V's spoken responses). The API returns audio at 24kHz mono.
 */
class AudioPlayback {

    companion object {
        const val OUTPUT_SAMPLE_RATE = 24_000
    }

    private var track: AudioTrack? = null

    fun start() {
        val minBufferSize = AudioTrack.getMinBufferSize(
            OUTPUT_SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(OUTPUT_SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(minBufferSize * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        track?.play()
    }

    /** Feed one chunk of PCM16 audio bytes received from the socket. */
    fun write(chunk: ByteArray) {
        track?.write(chunk, 0, chunk.size)
    }

    fun stop() {
        track?.stop()
        track?.release()
        track = null
    }
}
