package com.dhara.ev.ui.screens

import android.Manifest
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import com.dhara.ev.ui.theme.EvBlueNeon
import com.dhara.ev.ui.theme.EvPurpleNeon
import com.dhara.ev.ui.theme.EvTextSecondary
import com.dhara.ev.ui.theme.glassPanel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun CameraVisionScreen(viewModel: CameraVisionViewModel = hiltViewModel()) {
    val cameraPermission = rememberPermissionState(Manifest.permission.CAMERA)
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val result by viewModel.result.collectAsState()

    LaunchedEffect(Unit) {
        if (!cameraPermission.status.isGranted) cameraPermission.launchPermissionRequest()
    }

    Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        if (cameraPermission.status.isGranted) {
            AndroidView(
                factory = { ctx ->
                    val previewView = PreviewView(ctx)
                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    cameraProviderFuture.addListener({
                        val cameraProvider = cameraProviderFuture.get()

                        val preview = Preview.Builder().build().also {
                            it.setSurfaceProvider(previewView.surfaceProvider)
                        }

                        val analysis = ImageAnalysis.Builder()
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .build()
                            .also { it.setAnalyzer(ContextCompat.getMainExecutor(ctx), viewModel.analyzer) }

                        cameraProvider.unbindAll()
                        cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            CameraSelector.DEFAULT_BACK_CAMERA,
                            preview,
                            analysis
                        )
                    }, ContextCompat.getMainExecutor(ctx))
                    previewView
                },
                modifier = Modifier.fillMaxSize()
            )

            // Bounding-box overlay for detected faces/objects.
            Canvas(modifier = Modifier.fillMaxSize()) {
                if (result.imageWidth == 0 || result.imageHeight == 0) return@Canvas
                val scaleX = size.width / result.imageHeight // rotated frame: width/height swapped
                val scaleY = size.height / result.imageWidth

                result.faces.forEach { face ->
                    drawRect(
                        color = EvPurpleNeon,
                        topLeft = Offset(face.boundingBoxLeft * scaleX, face.boundingBoxTop * scaleY),
                        size = Size(
                            (face.boundingBoxRight - face.boundingBoxLeft) * scaleX,
                            (face.boundingBoxBottom - face.boundingBoxTop) * scaleY
                        ),
                        style = Stroke(width = 4f)
                    )
                }
                result.objects.forEach { obj ->
                    drawRect(
                        color = EvBlueNeon,
                        topLeft = Offset(obj.boundingBoxLeft * scaleX, obj.boundingBoxTop * scaleY),
                        size = Size(
                            (obj.boundingBoxRight - obj.boundingBoxLeft) * scaleX,
                            (obj.boundingBoxBottom - obj.boundingBoxTop) * scaleY
                        ),
                        style = Stroke(width = 3f)
                    )
                }
            }

            // Live readout panel.
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(16.dp)
                    .glassPanel()
                    .padding(16.dp)
            ) {
                Text("Faces: ${result.faces.size}   Objects: ${result.objects.size}", color = MaterialTheme.colorScheme.onBackground)
                result.text?.let {
                    Spacer(Modifier.height(6.dp))
                    Text("Text seen: ${it.text.take(120)}", color = EvTextSecondary, maxLines = 3)
                }
            }
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "Camera access is needed for E.V to see.",
                    color = EvTextSecondary,
                    modifier = Modifier.glassPanel().padding(20.dp)
                )
            }
        }
    }
}
