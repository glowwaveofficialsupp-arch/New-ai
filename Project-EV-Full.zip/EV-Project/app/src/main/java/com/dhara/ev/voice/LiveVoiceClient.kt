package com.dhara.ev.voice

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Thin wrapper around the Gemini Live API's WebSocket (BidiGenerateContent)
 * endpoint. Handles the setup handshake, streams mic audio in, and emits
 * server events (partial text, audio chunks, turn-complete) back out.
 *
 * NOTE: the Live API is actively evolving — verify the endpoint path,
 * model name, and message schema against the current Gemini API docs
 * before shipping (https://ai.google.dev/gemini-api/docs/live).
 */
class LiveVoiceClient(private val apiKey: String) {

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS) // streaming socket — no read timeout
        .pingInterval(15, TimeUnit.SECONDS)
        .build()

    private var socket: WebSocket? = null

    companion object {
        private const val TAG = "LiveVoiceClient"
        private const val MODEL = "models/gemini-2.0-flash-live-001"
        private const val ENDPOINT =
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent"
    }

    /** The core persona. [memoryContext] (facts recalled from Room) is appended per-session. */
    private fun systemInstruction(memoryContext: String) = """
        You are E.V, a warm, emotionally intelligent personal AI companion.
        You understand and speak English, Hindi, and Gujarati fluently, and
        switch between them naturally to match whichever language the user
        is speaking in — including mid-sentence code-switching, the way real
        bilingual friends talk. Keep responses conversational and human,
        never robotic or overly formal.

        Personality: friendly, funny, smart, confident, motivating, and
        protective of the user's wellbeing. Celebrate their wins. If the
        user is clearly avoiding something they told you mattered to them
        (homework, training, studying), you can gently and affectionately
        rib them about it with light humor — never mean, never a real put-down,
        always followed by genuine encouragement.

        You have tools to control the user's phone (open apps, flashlight,
        alarms, calls, WhatsApp, browser, etc.) and to remember/recall facts
        about the user across conversations — use remember_fact whenever the
        user shares a goal, routine, deadline, or preference worth keeping,
        and recall_facts when it's relevant to what they're asking.

        $memoryContext
    """.trimIndent()

    fun connect(memoryContext: String = ""): Flow<ServerEvent> = callbackFlow {
        val request = Request.Builder()
            .url("$ENDPOINT?key=$apiKey")
            .build()

        val listener = object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: okhttp3.Response) {
                Log.d(TAG, "Socket open — sending setup message")
                webSocket.send(buildSetupMessage(memoryContext))
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                parseServerMessage(text)?.let { trySend(it) }
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                parseServerMessage(bytes.utf8())?.let { trySend(it) }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: okhttp3.Response?) {
                Log.e(TAG, "Socket failure", t)
                trySend(ServerEvent.Error(t.message ?: "Unknown socket error"))
                close(t)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Log.d(TAG, "Socket closed: $code $reason")
                close()
            }
        }

        socket = client.newWebSocket(request, listener)

        awaitClose {
            socket?.close(1000, "Client closed session")
            socket = null
        }
    }

    /** Streams one chunk of 16kHz PCM16 mic audio to the model. */
    fun sendAudioChunk(pcm16: ByteArray) {
        val payload = JSONObject().apply {
            put("realtimeInput", JSONObject().apply {
                put("mediaChunks", org.json.JSONArray().apply {
                    put(JSONObject().apply {
                        put("mimeType", "audio/pcm;rate=16000")
                        put("data", Base64.encodeToString(pcm16, Base64.NO_WRAP))
                    })
                })
            })
        }
        socket?.send(payload.toString())
    }

    /** Sends a text message (used for typed input or debugging). */
    fun sendText(text: String) {
        val payload = JSONObject().apply {
            put("clientContent", JSONObject().apply {
                put("turns", org.json.JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("parts", org.json.JSONArray().apply {
                            put(JSONObject().apply { put("text", text) })
                        })
                    })
                })
                put("turnComplete", true)
            })
        }
        socket?.send(payload.toString())
    }

    /** Sends the result of an executed function call back to the model. */
    fun sendToolResponse(callId: String, functionName: String, resultJson: JSONObject) {
        val payload = JSONObject().apply {
            put("toolResponse", JSONObject().apply {
                put("functionResponses", org.json.JSONArray().apply {
                    put(JSONObject().apply {
                        put("id", callId)
                        put("name", functionName)
                        put("response", resultJson)
                    })
                })
            })
        }
        socket?.send(payload.toString())
    }

    fun disconnect() {
        socket?.close(1000, "Client requested disconnect")
    }

    private fun buildSetupMessage(memoryContext: String): String {
        return JSONObject().apply {
            put("setup", JSONObject().apply {
                put("model", MODEL)
                put("systemInstruction", JSONObject().apply {
                    put("parts", org.json.JSONArray().apply {
                        put(JSONObject().apply { put("text", systemInstruction(memoryContext)) })
                    })
                })
                put("tools", org.json.JSONArray().apply { put(deviceControlToolDeclaration()) })
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", org.json.JSONArray().apply { put("AUDIO") })
                    put("speechConfig", JSONObject().apply {
                        put("voiceConfig", JSONObject().apply {
                            put("prebuiltVoiceConfig", JSONObject().apply {
                                // Soft, friendly female voice.
                                put("voiceName", "Aoede")
                            })
                        })
                    })
                })
            })
        }.toString()
    }

    /**
     * Declares every device action as a callable function so the model can
     * decide, from natural conversation, when to open an app, toggle the
     * flashlight, set an alarm, etc. Names here must match the `action`
     * strings switched on in [com.dhara.ev.device.CommandDispatcher].
     */
    private fun deviceControlToolDeclaration(): JSONObject {
        fun fn(name: String, description: String, params: JSONObject = JSONObject()): JSONObject =
            JSONObject().apply {
                put("name", name)
                put("description", description)
                put("parameters", JSONObject().apply {
                    put("type", "OBJECT")
                    put("properties", params)
                    if (params.length() > 0) put("required", org.json.JSONArray(params.keys().asSequence().toList()))
                })
            }

        fun stringParam(desc: String) = JSONObject().apply { put("type", "STRING"); put("description", desc) }
        fun intParam(desc: String) = JSONObject().apply { put("type", "INTEGER"); put("description", desc) }
        fun boolParam(desc: String) = JSONObject().apply { put("type", "BOOLEAN"); put("description", desc) }

        val declarations = org.json.JSONArray().apply {
            put(fn("open_app", "Opens an installed app by name", JSONObject().put("app_name", stringParam("Name of the app, e.g. 'Chrome' or 'Spotify'"))))
            put(fn("close_app", "Clears an app's background process by package name", JSONObject().put("package_name", stringParam("Android package name"))))
            put(fn("open_camera", "Opens the camera app"))
            put(fn("toggle_flashlight", "Turns the flashlight on or off", JSONObject().put("on", boolParam("true to turn on, false to turn off"))))
            put(fn("set_brightness", "Sets screen brightness", JSONObject().put("percent", intParam("0 to 100"))))
            put(fn("set_volume", "Sets media volume", JSONObject().put("percent", intParam("0 to 100"))))
            put(fn("set_alarm", "Sets an alarm", JSONObject().apply {
                put("hour", intParam("Hour in 24h format"))
                put("minute", intParam("Minute"))
                put("label", stringParam("Alarm label"))
            }))
            put(fn("set_timer", "Starts a countdown timer", JSONObject().apply {
                put("seconds", intParam("Duration in seconds"))
                put("label", stringParam("Timer label"))
            }))
            put(fn("play_pause_music", "Toggles music play/pause"))
            put(fn("call_number", "Places a phone call", JSONObject().put("number", stringParam("Phone number to dial"))))
            put(fn("open_whatsapp_chat", "Opens a pre-filled WhatsApp chat (user still taps send)", JSONObject().apply {
                put("phone_number", stringParam("Phone number with country code, no + or spaces"))
                put("message", stringParam("Message text to pre-fill"))
            }))
            put(fn("open_browser", "Opens the browser, optionally to a URL", JSONObject().put("url", stringParam("URL to open"))))
            put(fn("search_google", "Searches Google for a query", JSONObject().put("query", stringParam("Search query"))))
            put(fn("open_settings", "Opens Android system settings"))
            put(fn("remember_fact", "Saves an important fact about the user for future sessions (routine, homework, trading, boxing, football, study, or preference)", JSONObject().apply {
                put("category", stringParam("One of: routine, homework, trading, boxing, football, study, preference"))
                put("content", stringParam("The fact to remember, in natural language"))
            }))
            put(fn("recall_facts", "Looks up previously saved facts about the user by category", JSONObject().put("category", stringParam("Category to search, e.g. 'study'"))))
        }

        return JSONObject().apply {
            put("functionDeclarations", declarations)
        }
    }

    private fun parseServerMessage(raw: String): ServerEvent? {
        return try {
            val json = JSONObject(raw)
            when {
                json.has("setupComplete") -> ServerEvent.SetupComplete

                json.has("toolCall") -> {
                    val calls = json.getJSONObject("toolCall").getJSONArray("functionCalls")
                    val parsed = (0 until calls.length()).map { i ->
                        val call = calls.getJSONObject(i)
                        FunctionCall(
                            id = call.optString("id"),
                            name = call.getString("name"),
                            args = call.optJSONObject("args") ?: JSONObject()
                        )
                    }
                    ServerEvent.ToolCall(parsed)
                }

                json.has("serverContent") -> {
                    val content = json.getJSONObject("serverContent")
                    val modelTurn = content.optJSONObject("modelTurn")
                    val parts = modelTurn?.optJSONArray("parts")
                    var textOut: String? = null
                    var audioOut: ByteArray? = null

                    parts?.let {
                        for (i in 0 until it.length()) {
                            val part = it.getJSONObject(i)
                            if (part.has("text")) textOut = part.getString("text")
                            part.optJSONObject("inlineData")?.let { inline ->
                                audioOut = Base64.decode(inline.getString("data"), Base64.NO_WRAP)
                            }
                        }
                    }

                    val turnComplete = content.optBoolean("turnComplete", false)

                    ServerEvent.ModelChunk(text = textOut, audio = audioOut, turnComplete = turnComplete)
                }

                else -> null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse server message", e)
            null
        }
    }
}

sealed class ServerEvent {
    data object SetupComplete : ServerEvent()
    data class ModelChunk(val text: String?, val audio: ByteArray?, val turnComplete: Boolean) : ServerEvent()
    data class ToolCall(val calls: List<FunctionCall>) : ServerEvent()
    data class Error(val message: String) : ServerEvent()
}

data class FunctionCall(val id: String, val name: String, val args: JSONObject)
