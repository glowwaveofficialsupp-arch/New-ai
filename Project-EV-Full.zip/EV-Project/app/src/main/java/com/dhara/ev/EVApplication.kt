package com.dhara.ev

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Application entry point. Annotated for Hilt so every module
 * (voice, device control, vision, memory) can be injected wherever
 * it's needed without manual wiring.
 */
@HiltAndroidApp
class EVApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        // Global, one-time setup (crash reporting, logging, etc.) goes here.
        // Kept deliberately empty in the skeleton — no placeholder logic.
    }
}
