package com.dhara.ev.memory

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * A single remembered fact about the user — a preference, goal, habit,
 * or important date. `category` lets the personality layer query things
 * like "study reminders" or "trading reminders" specifically.
 */
@Entity(tableName = "memory_entries")
data class MemoryEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String,       // e.g. "routine", "homework", "trading", "boxing", "football", "study", "preference"
    val content: String,        // the actual fact, in natural language
    val createdAtMillis: Long,
    val importance: Int = 1     // 1-5, lets old low-importance memories be pruned first
)

@Dao
interface MemoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: MemoryEntry): Long

    @Query("SELECT * FROM memory_entries ORDER BY createdAtMillis DESC")
    fun getAll(): Flow<List<MemoryEntry>>

    @Query("SELECT * FROM memory_entries WHERE category = :category ORDER BY createdAtMillis DESC")
    suspend fun getByCategory(category: String): List<MemoryEntry>

    @Query("SELECT * FROM memory_entries WHERE content LIKE '%' || :keyword || '%'")
    suspend fun search(keyword: String): List<MemoryEntry>

    @Query("DELETE FROM memory_entries WHERE id = :id")
    suspend fun delete(id: Long)
}
