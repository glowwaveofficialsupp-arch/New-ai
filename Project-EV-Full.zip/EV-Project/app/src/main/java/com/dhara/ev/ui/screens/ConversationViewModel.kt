package com.dhara.ev.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dhara.ev.voice.ConversationTurn
import com.dhara.ev.voice.VoiceRepository
import com.dhara.ev.voice.VoiceSessionState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

@HiltViewModel
class ConversationViewModel @Inject constructor(
    private val voiceRepository: VoiceRepository
) : ViewModel() {

    val sessionState: StateFlow<VoiceSessionState> = voiceRepository.state
    val transcript: StateFlow<List<ConversationTurn>> = voiceRepository.transcript

    fun startListening() {
        voiceRepository.startSession(viewModelScope)
    }

    fun stopListening() {
        voiceRepository.endSession()
    }

    override fun onCleared() {
        super.onCleared()
        voiceRepository.endSession()
    }
}
