package com.dhara.ev.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.dhara.ev.ui.theme.EvBlueNeon
import com.dhara.ev.ui.theme.EvPurpleNeon
import com.dhara.ev.ui.theme.EvTextSecondary
import com.dhara.ev.ui.theme.glassPanel

@Composable
fun HomeScreen(
    onOpenConversation: () -> Unit,
    onOpenCamera: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Spacer(Modifier.height(48.dp))

            Text(
                text = "E.V",
                style = MaterialTheme.typography.displayLarge,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Your intelligent companion",
                style = MaterialTheme.typography.bodyMedium,
                color = EvTextSecondary
            )

            Spacer(Modifier.height(56.dp))

            // Central pulsing orb — the visual anchor of the assistant.
            // Real breathing/listening animation wires in during Step 2
            // once there's live audio amplitude data to react to.
            Box(
                modifier = Modifier
                    .size(180.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(EvPurpleNeon.copy(alpha = 0.9f), EvBlueNeon.copy(alpha = 0.2f))
                        )
                    )
                    .clickable { onOpenConversation() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Tap to talk",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            }

            Spacer(Modifier.height(56.dp))

            ActionCard(title = "Talk to E.V", subtitle = "Voice conversation", onClick = onOpenConversation)
            Spacer(Modifier.height(16.dp))
            ActionCard(title = "Camera Vision", subtitle = "See what E.V sees", onClick = onOpenCamera)
            Spacer(Modifier.height(16.dp))
            ActionCard(title = "Settings", subtitle = "Preferences & memory", onClick = onOpenSettings)
        }
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .glassPanel(cornerRadius = 20)
            .clickable { onClick() }
            .padding(horizontal = 20.dp, vertical = 18.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = title, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
            Text(text = subtitle, style = MaterialTheme.typography.bodyMedium, color = EvTextSecondary)
        }
    }
}
