package com.dhara.ev.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp

private val EvDarkColorScheme = darkColorScheme(
    primary = EvPurpleNeon,
    onPrimary = EvBlackDeep,
    secondary = EvBlueNeon,
    onSecondary = EvBlackDeep,
    tertiary = EvCyanGlow,
    background = EvBlackDeep,
    onBackground = EvTextPrimary,
    surface = EvBlackSurface,
    onSurface = EvTextPrimary,
    surfaceVariant = EvBlackSurfaceElevated,
    onSurfaceVariant = EvTextSecondary,
    error = EvError
)

@Composable
fun EVTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = EvDarkColorScheme,
        typography = EvTypography,
        content = content
    )
}

/**
 * Reusable glassmorphism panel modifier: translucent surface, soft neon
 * border, rounded corners. Apply on top of a Box/Card/Column.
 */
fun Modifier.glassPanel(cornerRadius: Int = 24): Modifier = this
    .clip(RoundedCornerShape(cornerRadius.dp))
    .background(
        Brush.linearGradient(
            colors = listOf(EvGlassWhite, EvGlassWhite.copy(alpha = 0.04f))
        )
    )
    .border(
        width = 1.dp,
        brush = Brush.linearGradient(colors = listOf(EvPurpleNeon.copy(alpha = 0.5f), EvBlueNeon.copy(alpha = 0.3f))),
        shape = RoundedCornerShape(cornerRadius.dp)
    )
