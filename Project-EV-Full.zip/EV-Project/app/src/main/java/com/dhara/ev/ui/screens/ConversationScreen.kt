package com.dhara.ev.ui.screens

import android.Manifest
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.dhara.ev.ui.theme.*
import com.dhara.ev.voice.Speaker
import com.dhara.ev.voice.VoiceSessionState
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberPermissionState
import com.google.accompanist.permissions.isGranted

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun ConversationScreen(viewModel: ConversationViewModel = hiltViewModel()) {
    val micPermission = rememberPermissionState(Manifest.permission.RECORD_AUDIO)
    val state by viewModel.sessionState.collectAsState()
    val transcript by viewModel.transcript.collectAsState()

    Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {

            Text(
                text = statusLabel(state),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(Modifier.height(12.dp))

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(transcript) { turn ->
                    TranscriptBubble(text = turn.text, isUser = turn.speaker == Speaker.USER)
                }
            }

            Spacer(Modifier.height(16.dp))

            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(96.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = orbColors(state)
                            )
                        )
                        .then(
                            Modifier
                        )
                )
            }

            Spacer(Modifier.height(20.dp))

            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    if (!micPermission.status.isGranted) {
                        micPermission.launchPermissionRequest()
                        return@Button
                    }
                    if (state is VoiceSessionState.Idle) {
                        viewModel.startListening()
                    } else {
                        viewModel.stopListening()
                    }
                }
            ) {
                Text(if (state is VoiceSessionState.Idle) "Start talking" else "End conversation")
            }

            if (!micPermission.status.isGranted) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Microphone access is needed for E.V to hear you.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = EvTextSecondary
                )
            }
        }
    }
}

@Composable
private fun TranscriptBubble(text: String, isUser: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .glassPanel(cornerRadius = 16)
                .padding(12.dp)
        ) {
            Text(text = text, color = MaterialTheme.colorScheme.onBackground, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

private fun statusLabel(state: VoiceSessionState): String = when (state) {
    VoiceSessionState.Idle -> "Ready when you are"
    VoiceSessionState.Connecting -> "Connecting…"
    VoiceSessionState.Listening -> "Listening…"
    VoiceSessionState.Thinking -> "Thinking…"
    VoiceSessionState.Speaking -> "Speaking…"
    is VoiceSessionState.Error -> "Something went wrong: ${state.message}"
}

private fun orbColors(state: VoiceSessionState) = when (state) {
    VoiceSessionState.Listening -> listOf(EvBlueNeon, EvBlueDeep)
    VoiceSessionState.Speaking -> listOf(EvPurpleNeon, EvPurpleDeep)
    VoiceSessionState.Thinking -> listOf(EvCyanGlow, EvBlueDeep)
    is VoiceSessionState.Error -> listOf(EvError, EvBlackSurface)
    else -> listOf(EvTextDisabled, EvBlackSurface)
}
