package com.dhara.ev.navigation

/**
 * Single source of truth for every screen route in the app.
 * New screens (voice, camera, memory dashboard, coach modules)
 * get added here as they're built in later steps.
 */
sealed class EVDestination(val route: String) {
    data object Home : EVDestination("home")
    data object Conversation : EVDestination("conversation")
    data object CameraVision : EVDestination("camera_vision")
    data object Settings : EVDestination("settings")
}
