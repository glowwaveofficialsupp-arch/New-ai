package com.dhara.ev.vision

data class DetectedFace(val boundingBoxLeft: Float, val boundingBoxTop: Float, val boundingBoxRight: Float, val boundingBoxBottom: Float, val smilingProbability: Float?)
data class DetectedObject(val label: String, val confidence: Float, val boundingBoxLeft: Float, val boundingBoxTop: Float, val boundingBoxRight: Float, val boundingBoxBottom: Float)
data class DetectedText(val text: String)

data class VisionFrameResult(
    val faces: List<DetectedFace> = emptyList(),
    val objects: List<DetectedObject> = emptyList(),
    val text: DetectedText? = null,
    val imageWidth: Int = 0,
    val imageHeight: Int = 0
)
