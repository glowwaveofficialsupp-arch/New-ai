package com.dhara.ev.memory

import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MemoryRepository @Inject constructor(
    private val db: EVDatabase
) {
    private val dao get() = db.memoryDao()

    fun observeAll(): Flow<List<MemoryEntry>> = dao.getAll()

    suspend fun remember(category: String, content: String, importance: Int = 1): Long =
        dao.insert(
            MemoryEntry(
                category = category,
                content = content,
                createdAtMillis = System.currentTimeMillis(),
                importance = importance
            )
        )

    suspend fun recall(category: String): List<MemoryEntry> = dao.getByCategory(category)

    suspend fun search(keyword: String): List<MemoryEntry> = dao.search(keyword)

    suspend fun forget(id: Long) = dao.delete(id)

    /**
     * Builds a compact context block to prepend to the AI's system
     * instruction each session, so it "remembers" the user across app
     * restarts without re-explaining everything (poor-man's long-term
     * memory until a vector-search version is warranted).
     */
    suspend fun buildContextSummary(): String {
        val categories = listOf("routine", "homework", "trading", "boxing", "football", "study", "preference")
        val lines = categories.flatMap { category ->
            recall(category).take(5).map { "- [$category] ${it.content}" }
        }
        if (lines.isEmpty()) return ""
        return "Here's what you already know about the user:\n" + lines.joinToString("\n")
    }
}
