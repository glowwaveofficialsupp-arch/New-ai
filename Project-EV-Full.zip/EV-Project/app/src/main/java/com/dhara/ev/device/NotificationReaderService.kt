package com.dhara.ev.device

import android.app.Notification
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.runBlocking

data class ReadableNotification(
    val appPackage: String,
    val title: String,
    val text: String,
    val postedAtMillis: Long
)

/**
 * Requires the user to enable this app under
 * Settings > Notification access — a special permission Android does not
 * allow requesting via a normal runtime dialog. Use [notificationAccessSettingsIntent]
 * to send the user to the right settings screen.
 */
class NotificationReaderService : NotificationListenerService() {

    companion object {
        private val _notifications = MutableSharedFlow<ReadableNotification>(replay = 0, extraBufferCapacity = 20)
        val notifications: SharedFlow<ReadableNotification> = _notifications.asSharedFlow()

        fun notificationAccessSettingsIntent(): Intent =
            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        fun isAccessGranted(context: Context): Boolean {
            val enabled = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
            return enabled?.contains(context.packageName) == true
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

        runBlocking {
            _notifications.emit(
                ReadableNotification(
                    appPackage = sbn.packageName,
                    title = title,
                    text = text,
                    postedAtMillis = sbn.postTime
                )
            )
        }
    }
}
