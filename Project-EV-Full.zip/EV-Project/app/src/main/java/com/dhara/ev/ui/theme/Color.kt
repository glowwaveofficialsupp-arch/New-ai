package com.dhara.ev.ui.theme

import androidx.compose.ui.graphics.Color

// Base backdrop
val EvBlackDeep = Color(0xFF07070C)
val EvBlackSurface = Color(0xFF101018)
val EvBlackSurfaceElevated = Color(0xFF16161F)

// Neon accents
val EvPurpleNeon = Color(0xFFA855F7)
val EvPurpleDeep = Color(0xFF6D28D9)
val EvBlueNeon = Color(0xFF38BDF8)
val EvBlueDeep = Color(0xFF1E3A8A)
val EvCyanGlow = Color(0xFF22D3EE)

// Status / feedback
val EvSuccess = Color(0xFF34D399)
val EvWarning = Color(0xFFFBBF24)
val EvError = Color(0xFFF87171)

// Text
val EvTextPrimary = Color(0xFFF5F5FA)
val EvTextSecondary = Color(0xFFA1A1AE)
val EvTextDisabled = Color(0xFF5A5A66)

// Glass surfaces (used with alpha for glassmorphism panels)
val EvGlassWhite = Color(0x14FFFFFF)
val EvGlassBorder = Color(0x33A855F7)
