package com.dhara.ev.voice

/** Lifecycle state of the live voice connection, surfaced to the UI. */
sealed class VoiceSessionState {
    data object Idle : VoiceSessionState()
    data object Connecting : VoiceSessionState()
    data object Listening : VoiceSessionState()
    data object Thinking : VoiceSessionState()
    data object Speaking : VoiceSessionState()
    data class Error(val message: String) : VoiceSessionState()
}

/** A single turn in the conversation, used for transcript + memory. */
data class ConversationTurn(
    val speaker: Speaker,
    val text: String,
    val timestampMillis: Long,
    val detectedLanguage: Language? = null
)

enum class Speaker { USER, EV }

/** The three languages E.V must understand and switch between naturally. */
enum class Language(val code: String, val displayName: String) {
    ENGLISH("en-IN", "English"),
    HINDI("hi-IN", "Hindi"),
    GUJARATI("gu-IN", "Gujarati");

    companion object {
        fun fromCode(code: String): Language = entries.find { it.code == code } ?: ENGLISH
    }
}
