package com.dhara.ev.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.dhara.ev.ui.screens.CameraVisionScreen
import com.dhara.ev.ui.screens.ConversationScreen
import com.dhara.ev.ui.screens.HomeScreen
import com.dhara.ev.ui.screens.PlaceholderScreen

@Composable
fun EVNavGraph(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = EVDestination.Home.route) {

        composable(EVDestination.Home.route) {
            HomeScreen(
                onOpenConversation = { navController.navigate(EVDestination.Conversation.route) },
                onOpenCamera = { navController.navigate(EVDestination.CameraVision.route) },
                onOpenSettings = { navController.navigate(EVDestination.Settings.route) }
            )
        }

        composable(EVDestination.Conversation.route) {
            ConversationScreen()
        }

        composable(EVDestination.CameraVision.route) {
            CameraVisionScreen()
        }

        composable(EVDestination.Settings.route) {
            PlaceholderScreen(title = "Settings", subtitle = "Coming soon")
        }
    }
}
