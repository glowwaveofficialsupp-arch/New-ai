package com.dhara.ev.device

import com.dhara.ev.memory.MemoryRepository
import com.dhara.ev.voice.FunctionCall
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CommandDispatcher @Inject constructor(
    private val deviceController: DeviceController,
    private val memoryRepository: MemoryRepository
) {
    /** Executes the function the model requested and returns a JSON result for LiveVoiceClient.sendToolResponse. */
    suspend fun dispatch(call: FunctionCall): JSONObject {
        val args = call.args

        if (call.name == "remember_fact") {
            memoryRepository.remember(args.getString("category"), args.getString("content"))
            return JSONObject().apply { put("success", true); put("message", "Got it, I'll remember that") }
        }
        if (call.name == "recall_facts") {
            val facts = memoryRepository.recall(args.getString("category")).map { it.content }
            return JSONObject().apply {
                put("success", true)
                put("facts", org.json.JSONArray(facts))
            }
        }

        val result: CommandResult = when (call.name) {
            "open_app" -> deviceController.openApp(args.getString("app_name"))
            "close_app" -> deviceController.closeApp(args.getString("package_name"))
            "open_camera" -> deviceController.openCamera()
            "toggle_flashlight" -> deviceController.toggleFlashlight(args.optBoolean("on", true))
            "set_brightness" -> deviceController.setBrightness(args.getInt("percent"))
            "set_volume" -> deviceController.setVolume(args.getInt("percent"))
            "set_alarm" -> deviceController.setAlarm(
                hour = args.getInt("hour"),
                minute = args.getInt("minute"),
                label = args.optString("label", "E.V alarm")
            )
            "set_timer" -> deviceController.setTimer(
                seconds = args.getInt("seconds"),
                label = args.optString("label", "E.V timer")
            )
            "play_pause_music" -> deviceController.playPauseMusic()
            "call_number" -> deviceController.callNumber(args.getString("number"))
            "open_whatsapp_chat" -> deviceController.openWhatsAppChat(
                phoneNumberWithCountryCode = args.getString("phone_number"),
                message = args.optString("message", "")
            )
            "open_browser" -> deviceController.openBrowser(args.optString("url", "https://www.google.com"))
            "search_google" -> deviceController.searchGoogle(args.getString("query"))
            "open_settings" -> deviceController.openSettings()
            else -> CommandResult(false, "Unknown command: ${call.name}")
        }

        return JSONObject().apply {
            put("success", result.success)
            put("message", result.message)
        }
    }
}
