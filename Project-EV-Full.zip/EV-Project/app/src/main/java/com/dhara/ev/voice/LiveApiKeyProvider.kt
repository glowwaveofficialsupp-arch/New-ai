package com.dhara.ev.voice

import com.dhara.ev.BuildConfig
import javax.inject.Inject

/**
 * Reads the Gemini API key injected at build time via BuildConfig
 * (sourced from `local.properties`, which is gitignored — see the
 * project README for setup). Never hardcode the key in source.
 */
class LiveApiKeyProvider @Inject constructor() {
    fun getKey(): String {
        check(BuildConfig.GEMINI_API_KEY.isNotBlank()) {
            "Missing GEMINI_API_KEY. Add gemini.api.key=YOUR_KEY to local.properties"
        }
        return BuildConfig.GEMINI_API_KEY
    }
}
