package com.dhara.ev.voice

import com.dhara.ev.device.CommandDispatcher
import com.dhara.ev.memory.MemoryRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The single object the ViewModel talks to. Wires together mic capture,
 * the Live API socket, speaker playback, and device-command execution so
 * the UI layer never has to think about audio formats, WebSocket framing,
 * or which Android API a given voice command maps to.
 */
@Singleton
class VoiceRepository @Inject constructor(
    private val apiKeyProvider: LiveApiKeyProvider,
    private val commandDispatcher: CommandDispatcher,
    private val memoryRepository: MemoryRepository
) {
    private val audioCapture = AudioCapture()
    private val audioPlayback = AudioPlayback()
    private var liveClient: LiveVoiceClient? = null
    private var captureJob: Job? = null
    private var socketJob: Job? = null

    private val _state = MutableStateFlow<VoiceSessionState>(VoiceSessionState.Idle)
    val state: StateFlow<VoiceSessionState> = _state.asStateFlow()

    private val _transcript = MutableStateFlow<List<ConversationTurn>>(emptyList())
    val transcript: StateFlow<List<ConversationTurn>> = _transcript.asStateFlow()

    private var partialModelText = StringBuilder()

    fun startSession(scope: CoroutineScope) {
        _state.value = VoiceSessionState.Connecting
        val client = LiveVoiceClient(apiKeyProvider.getKey())
        liveClient = client
        audioPlayback.start()

        socketJob = scope.launch {
            val memoryContext = memoryRepository.buildContextSummary()
            client.connect(memoryContext).collect { event ->
                when (event) {
                    is ServerEvent.SetupComplete -> {
                        _state.value = VoiceSessionState.Listening
                        beginMicStreaming(scope, client)
                    }
                    is ServerEvent.ModelChunk -> {
                        _state.value = VoiceSessionState.Speaking
                        event.text?.let { partialModelText.append(it) }
                        event.audio?.let { audioPlayback.write(it) }
                        if (event.turnComplete) {
                            if (partialModelText.isNotEmpty()) {
                                appendTurn(Speaker.EV, partialModelText.toString())
                                partialModelText = StringBuilder()
                            }
                            _state.value = VoiceSessionState.Listening
                        }
                    }
                    is ServerEvent.Error -> {
                        _state.value = VoiceSessionState.Error(event.message)
                    }
                    is ServerEvent.ToolCall -> {
                        event.calls.forEach { call ->
                            val resultJson = commandDispatcher.dispatch(call)
                            client.sendToolResponse(call.id, call.name, resultJson)
                        }
                    }
                }
            }
        }
    }

    private fun beginMicStreaming(scope: CoroutineScope, client: LiveVoiceClient) {
        captureJob = scope.launch {
            audioCapture.start().collect { chunk ->
                client.sendAudioChunk(chunk)
            }
        }
    }

    /** Optional: send typed text instead of / alongside voice. */
    fun sendText(text: String) {
        appendTurn(Speaker.USER, text)
        liveClient?.sendText(text)
        _state.value = VoiceSessionState.Thinking
    }

    private fun appendTurn(speaker: Speaker, text: String) {
        _transcript.value = _transcript.value + ConversationTurn(
            speaker = speaker,
            text = text,
            timestampMillis = System.currentTimeMillis()
        )
    }

    fun endSession() {
        captureJob?.cancel()
        socketJob?.cancel()
        liveClient?.disconnect()
        audioPlayback.stop()
        _state.value = VoiceSessionState.Idle
    }
}
