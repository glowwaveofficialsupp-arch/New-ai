package com.dhara.ev.voice

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.Dispatchers

/**
 * Captures microphone audio as raw 16-bit PCM mono at 16kHz — the format
 * the Gemini Live API expects for realtime input. Emits chunks as a Flow
 * so the voice repository can pipe them straight into the socket.
 */
class AudioCapture {

    companion object {
        const val SAMPLE_RATE = 16_000
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
    }

    @SuppressLint("MissingPermission") // caller must have checked RECORD_AUDIO first
    fun start(): Flow<ByteArray> = callbackFlow {
        val minBufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
        require(minBufferSize > 0) { "Device does not support required audio config" }

        val bufferSize = minBufferSize * 2
        val recorder = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            SAMPLE_RATE,
            CHANNEL_CONFIG,
            AUDIO_FORMAT,
            bufferSize
        )

        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            close(IllegalStateException("AudioRecord failed to initialize"))
            return@callbackFlow
        }

        recorder.startRecording()
        val buffer = ByteArray(bufferSize)

        val thread = Thread {
            while (!isClosedForSend) {
                val read = recorder.read(buffer, 0, buffer.size)
                if (read > 0) {
                    trySend(buffer.copyOf(read))
                }
            }
        }
        thread.start()

        awaitClose {
            recorder.stop()
            recorder.release()
        }
    }.flowOn(Dispatchers.IO)
}
