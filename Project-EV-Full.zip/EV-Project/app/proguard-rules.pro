# Add project specific ProGuard rules here as native/reflection-based
# libraries (ML Kit, OkHttp) are integrated in later build steps.
